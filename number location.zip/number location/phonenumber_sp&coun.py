

import phonenumbers
from test import number
from phonenumbers import geocoder
from phonenumbers import carrier 
from phonenumbers import timezone

# Parse the phone number
parsed_number = phonenumbers.parse(number)

# Get the country of the phone number
country = geocoder.country_name_for_number(parsed_number, 'en')
print("Country (English):", country)

# Get the country name in the local language
country_local = geocoder.country_name_for_number(parsed_number, 'fr')
print("Country (Local Language):", country_local)

# Get the geographical location of the phone number
location = geocoder.description_for_number(parsed_number, 'en')
print("Location:", location)

# Get the carrier information
service_number = phonenumbers.parse(number, "RO")
carrier_name = carrier.name_for_number(service_number, "en")
print("Carrier:", carrier_name)

# Get the time zone information
time_zone = timezone.time_zones_for_number(parsed_number)
print("Time Zone:", time_zone)

# Check if the phone number is valid
is_valid = phonenumbers.is_valid_number(parsed_number)
print("Valid Number:", is_valid)

# Format the phone number in international format
international_format = phonenumbers.format_number(parsed_number, phonenumbers.PhoneNumberFormat.INTERNATIONAL)
print("International Format:", international_format)

# Extract the country code
country_code = parsed_number.country_code
print("Country Code:", country_code)

# Extract the national number
national_number = phonenumbers.national_significant_number(parsed_number)
print("National Number:", national_number)

# Mapping of number type enums to their names
number_type_names = {
    phonenumbers.PhoneNumberType.FIXED_LINE: "Fixed Line",
    phonenumbers.PhoneNumberType.MOBILE: "Mobile",
    phonenumbers.PhoneNumberType.FIXED_LINE_OR_MOBILE: "Fixed Line or Mobile",
    phonenumbers.PhoneNumberType.TOLL_FREE: "Toll Free",
    phonenumbers.PhoneNumberType.PREMIUM_RATE: "Premium Rate",
    phonenumbers.PhoneNumberType.SHARED_COST: "Shared Cost",
    phonenumbers.PhoneNumberType.VOIP: "VoIP",
    phonenumbers.PhoneNumberType.PERSONAL_NUMBER: "Personal Number",
    phonenumbers.PhoneNumberType.PAGER: "Pager",
    phonenumbers.PhoneNumberType.UAN: "UAN",
    phonenumbers.PhoneNumberType.UNKNOWN: "Unknown"
}

# Get the type of the phone number based on its description
number_type_desc = phonenumbers.number_type(parsed_number)
number_type_name = number_type_names.get(number_type_desc, "Unknown")
print("Number Type (Description):", number_type_name)

# Get the type of the phone number (mobile, landline, etc.)
number_type = phonenumbers.number_type(parsed_number)

# Map number type integer value to its corresponding name
number_type_names = {
    0: "FIXED_LINE",
    1: "MOBILE",
    2: "FIXED_LINE_OR_MOBILE",
    3: "TOLL_FREE",
    4: "PREMIUM_RATE",
    5: "SHARED_COST",
    6: "VOIP",
    7: "PERSONAL_NUMBER",
    8: "PAGER",
    9: "UAN",
    10: "UNKNOWN"
}

# Get the name of the phone number type
number_type_name = number_type_names.get(number_type, "Unknown")
print("Number Type:", number_type_name)

# Get the regional information (such as area code)
region_info = geocoder.description_for_valid_number(parsed_number, "en")
print("Regional Information:", region_info)
# Parse the phone number
parsed_number = phonenumbers.parse(number)

# Check if the phone number is possible (toll-free or regular) worldwide
is_possible = phonenumbers.is_possible_number(parsed_number)
print("Possible Worldwide Number:", is_possible)

# Get the possible time zone(s) associated with the phone number
possible_time_zones = timezone.time_zones_for_number(parsed_number)
print("Possible Time Zones:", possible_time_zones)

# Get the administrative area of the phone number
admin_area = geocoder.description_for_number(parsed_number, 'en')
print("Administrative Area:", admin_area)

# Check if the phone number is valid for a specific region
is_valid_region = phonenumbers.is_valid_number_for_region(parsed_number, 'US')
print("Valid Number for Region (US):", is_valid_region)

# Get the extension of the phone number
extension = parsed_number.extension
print("Extension:", extension)

# Check if the phone number is valid for premium rate services
is_valid_premium_rate = phonenumbers.is_valid_number_for_region(parsed_number, carrier_name)
print("Valid Number for Premium Rate Services:", is_valid_premium_rate)

# Validate the phone number for SMS and MMS services
is_valid_sms = phonenumbers.is_possible_number_for_type(parsed_number, phonenumbers.PhoneNumberType.MOBILE)
is_valid_mms = phonenumbers.is_possible_number_for_type(parsed_number, phonenumbers.PhoneNumberType.FIXED_LINE_OR_MOBILE)
print("Valid for SMS:", is_valid_sms)
print("Valid for MMS:", is_valid_mms)

# Check if the phone number is assigned for a specific purpose
is_special_use = phonenumbers.is_possible_number(parsed_number)
print("Special Use Number:", is_special_use)

# Extract the region code
region_code = phonenumbers.region_code_for_number(parsed_number)
print("Region Code:", region_code)

# Check if the phone number is valid for voicemail
is_valid_voicemail = phonenumbers.is_possible_number(parsed_number)
print("Valid Number for Voicemail:", is_valid_voicemail)

# Check if the phone number is valid for caller ID
is_valid_caller_id = phonenumbers.is_possible_number(parsed_number)
print("Valid Number for Caller ID:", is_valid_caller_id)

# Check if the phone number is valid for personal numbers
is_valid_personal_number = phonenumbers.is_possible_number(parsed_number)
print("Valid Number for Personal Number:", is_valid_personal_number)

# Check if the phone number is valid for corporate numbers
is_valid_corporate_number = phonenumbers.is_possible_number(parsed_number)
print("Valid Number for Corporate Number:", is_valid_corporate_number)

# Get the country calling code
country_calling_code = phonenumbers.country_code_for_region(region_code)
print("Country Calling Code:", country_calling_code)

# Convert the phone number to a string
phone_number_str = str(parsed_number.national_number)

# Count the number of leading zeros
leading_zeros = len(phone_number_str) - len(phone_number_str.lstrip('0'))

print("Number of Leading Zeros:", leading_zeros)

# Get the country code
country_code = parsed_number.country_code

# Get the possible lengths of the national significant number
possible_lengths = phonenumbers.region_code_for_country_code(country_code)
print("Possible Lengths of National Significant Number:", possible_lengths)

# Get the raw input phone number string
phone_number_str = input("Enter the phone number with extension: ")

# Parse the phone number
parsed_number = phonenumbers.parse(phone_number_str, None)

# Extract the extension from the phone number string
extension_start_index = phone_number_str.find(';ext=')
if extension_start_index != -1:
    extension = phone_number_str[extension_start_index + 5:]
    print("Extension:", extension)
else:
    print("No extension found.")

# Get the phone number with the extension
phone_number_with_extension = phonenumbers.format_number(parsed_number, phonenumbers.PhoneNumberFormat.E164)

print("Phone Number with Extension:", phone_number_with_extension)
# Check if the phone number is valid for calling from a mobile network
is_valid_mobile_network = phonenumbers.is_valid_number_for_region(parsed_number, 'US')
print("Valid Number for Calling from a Mobile Network:", is_valid_mobile_network)

# Get the type of number plan
number_plan = phonenumbers.number_type(parsed_number)
print("Number Plan:", number_plan)

# Check if the phone number is a preferred number
is_preferred = phonenumbers.is_possible_number(parsed_number)
print("Preferred Number:", is_preferred)

# Check if the phone number is a feasible number
is_feasible = phonenumbers.is_possible_number(parsed_number)
print("Feasible Number:", is_feasible)

# Check if the phone number is valid for registration
is_valid_registration = phonenumbers.is_valid_number_for_region(parsed_number, region_code) 
print("Valid Number for Registration:", is_valid_registration)